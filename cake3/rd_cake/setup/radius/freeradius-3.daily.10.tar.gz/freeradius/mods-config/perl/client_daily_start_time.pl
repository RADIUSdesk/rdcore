#! /usr/bin/perl -w
use strict;
use POSIX;
use DateTime;

# use ...
# This is very important !
use vars qw(%RAD_CHECK);
use constant RLM_MODULE_OK=> 2; # /* the module is OK,continue */
use constant RLM_MODULE_NOOP=> 7;
use constant RLM_MODULE_UPDATED=> 8; # /* OK (pairs modified) */

# Same as src/include/radiusd.h
use constant	L_DBG=>   1;
use constant	L_AUTH=>  2;
use constant	L_INFO=>  3;
use constant	L_ERR=>   4;
use constant	L_PROXY=> 5;
use constant	L_ACCT=>  6;

use constant    DEFAULT_ZONE => 'UTC';

sub authorize {
 
    $RAD_CHECK{'Rd-Daily-Data-Start-Time'} = start_of_day($RAD_CHECK{'Rd-Daily-Data-Limit-Reset-Hour'},$RAD_CHECK{'Rd-Daily-Data-Limit-Reset-Min'});
       
    if(exists($RAD_CHECK{'Rd-Daily-Data-Start-Time'})){
        return RLM_MODULE_UPDATED;    
    }else{
        return RLM_MODULE_NOOP;
    }
}

sub accounting {
 
    $RAD_CHECK{'Rd-Daily-Data-Start-Time'} = start_of_day($RAD_CHECK{'Rd-Daily-Data-Limit-Reset-Hour'},$RAD_CHECK{'Rd-Daily-Data-Limit-Reset-Min'});
       
    if(exists($RAD_CHECK{'Rd-Daily-Data-Start-Time'})){
        return RLM_MODULE_UPDATED;    
    }else{
        return RLM_MODULE_NOOP;
    }
}

sub start_of_day {
    #Send it the day, hour and minute to 
    my($r_hour,$r_min) = @_;
    my $dt_now = DateTime->now;
    $dt_now->set_time_zone($RAD_CHECK{'Rd-Nas-Timezone-Name'});
       
    my $dt_reset  = DateTime->new(
        year       => $dt_now->year,
        month      => $dt_now->month,
        day        => $dt_now->day,
        hour       => $r_hour,
        minute     => $r_min
    ); 
    $dt_reset->set_time_zone($RAD_CHECK{'Rd-Nas-Timezone-Name'});
     
    #IF we are BEFORE the reset date move one day back
    if($dt_now->epoch() < $dt_reset->epoch()){
        $dt_reset->subtract( days => 1 );       
    }
       
    print("NOW IS   ".$dt_now->strftime("%F %T")."\n");
    print("RESET ON ".$dt_reset->strftime("%F %T")."\n");
    
    &radiusd::radlog(L_DBG, "NOW IS ".$dt_now->strftime("%F %T")."\n");
    &radiusd::radlog(L_DBG, "RESET ON ".$dt_reset->strftime("%F %T")."\n");
    
    $dt_reset->set_time_zone(DEFAULT_ZONE); 
    return $dt_reset->epoch();
}


