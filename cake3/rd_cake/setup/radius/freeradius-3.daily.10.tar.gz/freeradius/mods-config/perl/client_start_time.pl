#! /usr/bin/perl -w
use strict;
use POSIX;
use DateTime;

# use ...
# This is very important !
use vars qw(%RAD_CHECK);
use constant RLM_MODULE_OK=> 2; # /* the module is OK,continue */
use constant RLM_MODULE_NOOP=> 7;
use constant RLM_MODULE_UPDATED=> 8; # /* OK (pairs modified) */

# Same as src/include/radiusd.h
use constant	L_DBG=>   1;
use constant	L_AUTH=>  2;
use constant	L_INFO=>  3;
use constant	L_ERR=>   4;
use constant	L_PROXY=> 5;
use constant	L_ACCT=>  6;

use constant    DEFAULT_ZONE => 'UTC';


sub authorize {
 
    $RAD_CHECK{'Rd-Data-Start-Time'} = start_of_month($RAD_CHECK{'Rd-Data-Limit-Reset-On'},$RAD_CHECK{'Rd-Data-Limit-Reset-Hour'},$RAD_CHECK{'Rd-Data-Limit-Reset-Min'});
       
    if(exists($RAD_CHECK{'Rd-Data-Start-Time'})){
        return RLM_MODULE_UPDATED;    
    }else{
        return RLM_MODULE_NOOP;
    }
}

sub accounting {
 
    $RAD_CHECK{'Rd-Data-Start-Time'} = start_of_month($RAD_CHECK{'Rd-Data-Limit-Reset-On'},$RAD_CHECK{'Rd-Data-Limit-Reset-Hour'},$RAD_CHECK{'Rd-Data-Limit-Reset-Min'});
       
    if(exists($RAD_CHECK{'Rd-Data-Start-Time'})){
        return RLM_MODULE_UPDATED;    
    }else{
        return RLM_MODULE_NOOP;
    }
}

sub start_of_month {
    #Send it the day, hour and minute to 
    my($r_day,$r_hour,$r_min) = @_;
  
    my $dt_now_tz = DateTime->now;
    $dt_now_tz->set_time_zone($RAD_CHECK{'Rd-Nas-Timezone-Name'});
    
    #Do this for values where $r_day is 31 and month only has 30 days
    my $last_day_of_month =  DateTime->last_day_of_month(year => $dt_now_tz->year, month => $dt_now_tz->month)->day;
    if($r_day > $last_day_of_month){
        $r_day = $last_day_of_month;
    }
    
    #Get the day of the month at this moment in time
    my $day_now = $dt_now_tz->day;
    
    my $dt_reset_tz  = DateTime->new(
        year       => $dt_now_tz->year,
        month      => $dt_now_tz->month,
        day        => $r_day,
        hour       => $r_hour,
        minute     => $r_min,
        time_zone  => $RAD_CHECK{'Rd-Nas-Timezone-Name'}
    );
    
    if($dt_now_tz->epoch() < $dt_reset_tz->epoch()){  #We use the previous month 
        $dt_reset_tz = $dt_reset_tz->clone->add(months => -1, end_of_month => 'preserve');
    }
    #print("NOW IS   ".$dt_now->strftime("%F %T")."\n");
    #print("RESET ON ".$dt_reset->strftime("%F %T")."\n");      
    &radiusd::radlog(L_DBG, "NOW IS ".$dt_now_tz->strftime("%F %T")."\n");
    &radiusd::radlog(L_DBG, "RESET ON ".$dt_reset_tz->strftime("%F %T")."\n");
    
    #Before we return we go bact to UTC since we need to be in UTC since we use Timezone in SQL again
   $dt_reset_tz->set_time_zone(DEFAULT_ZONE); 
    return $dt_reset_tz->epoch();
}


