<?php

namespace App\Controller;
use App\Controller\AppController;

use Cake\Core\Configure;
use Cake\Core\Configure\Engine\PhpConfig;

use Cake\Utility\Inflector;
use Cake\I18n\FrozenTime;
use Cake\I18n\Time;
use Cake\Utility\Hash;

use Cake\Datasource\ConnectionManager;

class MeshOverviewsLightController extends AppController{
  
    protected $base         = "Access Providers/Controllers/MeshOverviewsLight/";   
    protected $main_model   = 'Meshes';
    
    protected $tree_level_0 = 'STATE';
    protected $tree_level_1 = 'DISTRICT';
    protected $tree_level_2 = 'BLOCK';
  
    public function initialize(){  
        parent::initialize();
        $this->loadModel('Meshes');
        $this->loadModel('TreeTags'); 
        $this->loadModel('Users');    
        $this->loadComponent('Aa');
        $this->loadComponent('CommonQuery', [ //Very important to specify the Model
            'model'                     => 'Meshes',
            'no_available_to_siblings'  => false,
            'sort_by'                   => 'Meshes.name'
        ]); 
             
        $this->loadComponent('JsonErrors'); 
        $this->loadComponent('TimeCalculations');    
    }
    
    public function index(){
    
        //__ Authentication + Authorization __      
        $user = $this->Aa->user_for_token($this);
        if(!$user){   //If not a valid user
            return;
        }
        
        
        $conditions = ['TreeTags.parent_id IS NULL'];
        $tt_lookup  = [];
        $level      = 0;
        if(isset($this->request->query['tree_tag_id'])){
            $id = $this->request->query['tree_tag_id'];
            if($id != 0){
                $conditions = ['TreeTags.parent_id' => $id];          
            }    
        }              
        $q_tt = $this->{'TreeTags'}->find()->where($conditions)->all();
        $tt_lookup = [];
		$ov_items = [];
        foreach($q_tt as $tt){
			$tree_level = 'Root';
			$tree_tag_id = $tt->id;
            $tt_level  = $this->TreeTags->getLevel($tree_tag_id);
            if($tt_level == 0){
                $tree_level = $this->tree_level_0;
            }
            if($tt_level == 1){
                $tree_level = $this->tree_level_1;
            }
            if($tt_level == 2){
                $tree_level = $this->tree_level_2;
            }
			
			$ov_items[$tt->name] = [ 'id' => "$tt->id",'name' => "$tt->name",'parent_id' => "$tt->parent_id",'kml_file' => "$tt->kml_file",'center_lat' => "$tt->center_lat",'center_lng' => "$tt->center_lng",'clients' => 0, 'level' => "$tree_level"];
            $descendants = $this->{'TreeTags'}->find('children', ['for' => $tt->id]);
            $d_count = 0;
            foreach ($descendants as $tt_0) {
                $tt_lookup[$tt_0->id] = $tt->name;
                $d_count++; 
            }
            if($d_count == 0){
                $tt_lookup[$tt->id] = $tt->name;
            }    
        }
        $query = $this->{$this->main_model}->find();
        $this->CommonQuery->build_common_query($query,$user);
        $q_r  = $query->all();
        $s_mesh_list = '';
        $count = 0;
        foreach($q_r as $q){
            if($count == 0){
                $s_mesh_list = $q->id;
            }else{
                $s_mesh_list = $s_mesh_list.','.$q->id;
            } 
            $count++;     
        }
        $conn = ConnectionManager::get('default');
        
		// Default changed from hourly to daily
        $timespan = 'hourly'; 
		$rolling_table = 'rolling_last_hour';
        $seconds  = (60*60); //default is two hours
        //$timespan = 'daily'; //
		//$rolling_table = 'rolling_last_day';
        //$seconds = (60*60)*24; //default is two days
		
        if(isset($this->request->query['timespan'])){
            $timespan = $this->request->query['timespan'];
        }
        
        if($timespan == 'hourly'){
            $seconds = (60*60); //a hour
			$rolling_table = 'rolling_last_hour';
        }
        if($timespan == 'daily'){
            $seconds = (60*60)*24; //a day
			$rolling_table = 'rolling_last_day';
        }
        if($timespan == 'weekly'){
            $seconds = (60*60)*24*7; //a weeks
			$rolling_table = 'rolling_last_seven_days';
        }
        if($timespan == 'monthly'){
            $seconds = (60*60)*24*30; //30 Days
			$rolling_table = 'rolling_last_thirty_days';
        }

        $seconds_half = $seconds / 2;
                 
        $hour           = (60*60);
        $day            = $hour*24;
        $modified       = time()-$seconds;
        $modified_half  = time()-$seconds_half;
		
		$total = 0;
		$node_count = 0;
		$nodes_up	= 0;
		$nodes_down	= 0;
			
		//$ns_mesh_current = [];
		$data_mesh = 0;
		$data_mesh_prev = 0;
        
        $mesh_no_nodes  = 0;
        $mesh_down      = 0;
        $mesh_up        = 0;
        
        $total_nodes    = 0;
        $total_lv_nodes = 0;
        $t_nodes_up     = 0;
        $t_nodes_down   = 0;
        $t_lv_nodes_down   = 0;
		// Next are used for artificial Node Up Inflation Calc per MakSat Devl req.
		$c_tot_nodes_up = 0;
		$c_tot_nodes_down = 0;
		$c_tot_lv_nodes_down = 0;
		$ac_tot_nodes_up = 0;
		$ac_tot_lv_nodes_up = 0;
		$ac_tot_nodes_down = 0;
		$ac_tot_lv_nodes_down = 0;
		$c_tot_nodes = 0;
		$c_tot_lv_nodes = 0;
		$start_date = strtotime("2018-04-02");
		$cur_date = time();
		$art_day_diff = round(($cur_date - $start_date)/(60*60*24));
        $art_nodes_up     = 0;
        $art_lv_nodes_up  = 0;
        $art_nodes_down   = 0;
        $art_lv_nodes_down   = 0;
		// 
        $t_nodes_dual_radio     = 0;
        $t_nodes_single_radio   = 0;
        // uptime info
		$up_timesecs_tot = 0;
		$down_timesecs_tot = 0;
		$tot_time = 0;
		
        //client totals
        $client_count_now       = 0;
        $client_count_previous  = 0;
        $data_tx_now            = 0;
        $data_tx_before         = 0;
        $data_rx_now            = 0;
        $data_rx_before         = 0;
        
        //$ns_temp_current        = [];
        //$ns_temp_previous       = [];
        
        $data_usage                 = [];
        $data_usage['tx_current']   = 0;
        $data_usage['rx_current']   = 0;
        $data_usage['tx_previous']  = 0;
        $data_usage['rx_previous']  = 0;
		$items = [];
		$roll_up_data = [];
		$sortedItems = [];
		$noMeshes = false;

        if( $s_mesh_list != "") {

			// SQL for current data totaling
			$sql_statement_curr_data = [
				"select mesh_id, ",
				"	tree_tag_id, ",
				"	mesh_name, ",
				"	tot_clients, ",
				"	tot_tx_bytes, ",
				"	tot_rx_bytes, ",
				"	tot_bytes, ",
				"	tot_nodes, ",
				"	tot_lv_nodes, ",
				"	tot_lv_nodes_down, ",
				"	tot_nodes_down, ",
				"	tot_nodes_up, ",
				"	dual_radios, ",
				"	single_radios, ",
				"	nup_beg_remove_secs, ",
				"	nup_end_add_secs, ",
				"	nup_up_seconds, ",
				"	nup_down_seconds, ",
				"	ndwn_beg_remove_secs, ",
				"	ndwn_end_add_secs, ",
				"	ndwn_up_seconds, ",
				"	ndwn_down_seconds ",
				"from $rolling_table  ",
				" where mesh_id in ( $s_mesh_list ) ",
				"limit 0,50000 "
			];
			$stmt = $conn->execute(
				 implode($sql_statement_curr_data)
			);
			
			$c_rows = $stmt->fetchAll('assoc');
			// count everything
						
			foreach ($c_rows as $row) {
			
				$data_usage['tx_current']   = $data_usage['tx_current'] + $row['tot_tx_bytes'];
				$data_usage['rx_current']   = $data_usage['rx_current'] + $row['tot_rx_bytes'];
				$data_mesh 					= $data_mesh + $row['tot_bytes'];
				$client_count_now 			= $client_count_now + $row['tot_clients'];
			// Temp code for artificial Inflation of node count per MakSat Devl req.
				$c_tot_nodes_up 			= $row['tot_nodes_up'];
				$c_tot_nodes_down 			= $row['tot_nodes_down'];
				$c_tot_lv_nodes_down		= $row['tot_lv_nodes_down'];
				$c_tot_nodes 				= $row['tot_nodes'];
				$c_tot_lv_nodes 			= $row['tot_lv_nodes'];
				$ac_tot_nodes_down 			= $c_tot_nodes_down;
				$ac_tot_lv_nodes_down 		= $c_tot_lv_nodes_down;
				if ($c_tot_nodes_up == 1 && $c_tot_lv_nodes > 0){
					$ac_tot_nodes_up = ($c_tot_nodes_up + $art_day_diff) > $c_tot_nodes ? $c_tot_nodes : ($c_tot_nodes_up + $art_day_diff);
					$ac_tot_lv_nodes_up = ($c_tot_nodes_up + $art_day_diff) > $c_tot_lv_nodes ? $c_tot_lv_nodes : ($c_tot_nodes_up + $art_day_diff);
					$ac_tot_nodes_down = $c_tot_nodes - $ac_tot_nodes_up;
					$ac_tot_lv_nodes_down = $c_tot_lv_nodes - $ac_tot_lv_nodes_up;
					$art_nodes_up = $art_nodes_up + $ac_tot_nodes_up;
					$art_nodes_down = $art_nodes_down + $ac_tot_nodes_down;
					$art_lv_nodes_down = $art_lv_nodes_down + $ac_tot_lv_nodes_down;
				} else {
					$art_nodes_up = $art_nodes_up + $c_tot_nodes_up;
					$art_nodes_down = $art_nodes_down + $c_tot_nodes_down;
					$art_lv_nodes_down = $art_lv_nodes_down + $c_tot_lv_nodes_down;
				}

			//
				$t_nodes_up 				= $t_nodes_up + $row['tot_nodes_up'];
				$t_nodes_down 				= $t_nodes_down + $row['tot_nodes_down'];
				$t_lv_nodes_down 			= $t_lv_nodes_down + $row['tot_lv_nodes_down'];
				$t_nodes_dual_radio     	= $t_nodes_dual_radio + $row['dual_radios'];
				$t_nodes_single_radio   	= $t_nodes_single_radio + $row['single_radios'];
				$total_nodes 				= $total_nodes + $row['tot_nodes'];
				$total_lv_nodes				= $total_lv_nodes + $row['tot_lv_nodes'];
				$total++;					// APs (Meshes)
				$up_timesecs_tot 			= $up_timesecs_tot + abs( $row['nup_up_seconds']-$row['nup_beg_remove_secs']+$row['nup_end_add_secs'] );
				$down_timesecs_tot 			= $down_timesecs_tot + abs( $row['ndwn_down_seconds']-$row['ndwn_beg_remove_secs']+$row['ndwn_end_add_secs'] );

				if($row['tot_nodes'] == 0){
					$mesh_no_nodes = $mesh_no_nodes + 1;
				}
				
				if(($row['tot_nodes'] > 0)&&($row['tot_nodes_up'] == $row['tot_nodes'])){
					$mesh_up = $mesh_up + 1;
				}
				
				if(($row['tot_nodes'] > 0)&&($row['tot_nodes_down'] > 0)){
					$mesh_down = $mesh_down + 1;
				}
				
				if($row['tree_tag_id']){
					if (array_key_exists($row['tree_tag_id'],$tt_lookup) ){
						$roll_up_tag                = $tt_lookup[$row['tree_tag_id']];
					} else {
						// Leaf item
						$roll_up_tag = $row['mesh_name'];
						$ov_items[$roll_up_tag]['name'] = $row['mesh_name'];
						$ov_items[$roll_up_tag]['id'] = $row['mesh_id'];
					}
					if(isset($roll_up_data[$roll_up_tag])){
						$roll_up_data[$roll_up_tag]['clients'] = $roll_up_data[$roll_up_tag]['clients'] + $row['tot_clients'];
					}else{	
						$roll_up_data[$roll_up_tag]['clients'] = $row['tot_clients'];
					}				
				}
					
			}
			foreach ($roll_up_data as $key => $value){
				//print_r($ov_item);
				$ov_items[$key]['clients'] = $roll_up_data[$key]['clients'];
			}
			foreach ($ov_items as $key => $value){
				//print_r($ov_item);
				array_push($items,$value); 
			}
			// Sort by node state
			$sortedItems = Hash::sort($items, '{s}.name', 'asc');

		} else { // No meshes below tree_tag
			$noMeshes = true;
		}
			
		// uptime setup
		$tot_time = $up_timesecs_tot + $down_timesecs_tot;
		$time_up = 0;
		$time_down = 0;
		$up_pct = 0;
		$down_pct = 0;
		$uptimhistpct_current = [];
		
		if($up_timesecs_tot != 0){
			$time_up = round($modified_half/$up_timesecs_tot);
			$up_pct = round(($up_timesecs_tot/$tot_time)*100,2);
		}
		if($down_timesecs_tot != 0){
			$time_down = round($modified_half/$down_timesecs_tot);
			$down_pct = round(($down_timesecs_tot/$tot_time)*100,2);
		}
		$upread = $this->_secondsToTime($up_timesecs_tot);
		$downread = $this->_secondsToTime($down_timesecs_tot);
		if ($tot_time == 0){
			array_push($uptimhistpct_current,[ 'up_seconds' => 0,'up_pct' => 0,'up_minutes_readable' => "none"]);
			array_push($uptimhistpct_current,[ 'dwn_seconds' => 0,'dwn_pct' => 100,'dwn_minutes_readable' => "none"]);
		} else {
			if ($up_timesecs_tot != 0){
				array_push($uptimhistpct_current,[ 'up_seconds' => $up_timesecs_tot,'up_pct' => $up_pct,'up_minutes_readable' => "$upread"]);
			} else {
				array_push($uptimhistpct_current,[ 'up_seconds' => $up_timesecs_tot,'up_pct' => 0,'up_minutes_readable' => "none"]);
			}
			if ($down_timesecs_tot != 0){
				array_push($uptimhistpct_current,[ 'dwn_seconds' => $down_timesecs_tot,'dwn_pct' => $down_pct,'dwn_minutes_readable' => "$downread"]);
			} else {
				array_push($uptimhistpct_current,[ 'dwn_seconds' => $down_timesecs_tot,'dwn_pct' => 0,'dwn_minutes_readable' => "none"]);
			}
		}
		$network_info = [];
		if($mesh_no_nodes > 0){
			array_push($network_info,[ 'type' => 'info', 'detail' => "$mesh_no_nodes without any nodes"]);
		}
		
		if($mesh_down > 0){
			array_push($network_info,[  'type' => 'warning', 'detail' => "$mesh_down with offline nodes"]);
		}
		
		if($mesh_up > 0){
			array_push($network_info,[ 'type' => 'check', 'detail' => "$mesh_up with all online"]);
		}
		 //Data
		$data_slope                 = "flat";
		$data_now                   = $data_mesh;
		$data_previous              = $data_mesh_prev;   
		
		$data_usage['current']      = $this->formatted_bytes($data_mesh);
		$data_usage['tx_current']   = $this->formatted_bytes($data_usage['tx_current']);
		$data_usage['rx_current']   = $this->formatted_bytes($data_usage['rx_current']);
		$data_usage['previous']     = $this->formatted_bytes($data_mesh_prev);
		$data_usage['tx_previous']  = $this->formatted_bytes($data_usage['tx_previous']);
		$data_usage['rx_previous']  = $this->formatted_bytes($data_usage['rx_previous']); 
		
		if($data_previous == $data_now){
			$dataDelta = "0% increase";
		}else{ 
			if($data_now < $data_previous){
				//Decrease - How much
				if($data_now !== 0){
					$dataDelta = 100-(ceil(($data_now  / $data_previous ) * 100))."%";
				}else{
					$dataDelta = $this->formatted_bytes($data_previous);
				}
				$dataDelta = $dataDelta." decrease";
				$data_slope = "down";
			}
			
			if($data_now > $data_previous){
				//Increase - How much
				if($data_previous !== 0){
					$dataDelta = ceil(($data_now / $data_previous  ) * 100)."%";
				}else{
					$dataDelta = $this->formatted_bytes($data_now); 
				}
				$dataDelta = $dataDelta." increase";
				$data_slope = "up";
			}
		}
		
		$data_usage['dataDelta'] = $dataDelta;
		$data_usage['dataSlope'] = $data_slope;
		
		//Clients    
		$clients_slope              = "flat";
		if($client_count_previous == $client_count_now){
			$clientsDelta = "0% increase";
		}else{ 
			if($client_count_now < $client_count_previous){
				//Decrease - How much
				if($client_count_now !== 0){
					$clientsDelta = 100-(ceil(($client_count_now  / $client_count_previous ) * 100))."%";
				}else{
					$clientsDelta = $client_count_previous;
				}
				$clientsDelta = $clientsDelta." decrease";
				$clients_slope = "down";
			}
			
			if($client_count_now > $client_count_previous){
				//Increase - How much
				if($client_count_previous !== 0){
					$clientsDelta = ceil(($client_count_now / $client_count_previous  ) * 100)."%";
				}else{
					$clientsDelta = $client_count_now;
				}
				$clientsDelta = $clientsDelta." increase";
				$clients_slope = "up";
			}
		}
		
		//Include the level of the filter
		$tree_level = 'Root';
		if(isset($this->request->query['tree_tag_id'])){
			$tree_tag_id    = $this->request->query['tree_tag_id'];
			if($tree_tag_id !== '0'){
				$tt_level  = $this->TreeTags->getLevel($tree_tag_id);
				if($tt_level == 0){
					$tree_level = $this->tree_level_0;
				}
				if($tt_level == 1){
					$tree_level = $this->tree_level_1;
				}
				if($tt_level == 2){
					$tree_level = $this->tree_level_2;
				}
			}
		}
        // Artificial Online Node inflation per MakSat req.
			$art_lv_nodes_down = $total_lv_nodes - $art_nodes_up;
		//		
        $this->set(array(
            'success'       => true,
            'items'          => $sortedItems,
            'metaData'      => [
				'noMeshes'		=> $noMeshes,
                'networkCount'  => $total,
                'networkInfo'   => $network_info,
                'nodesCount'    => $total_nodes,
                'nodesLvCount'  => $total_lv_nodes,
                'nodesUp'       => $t_nodes_up,
                'nodesDown'     => $t_nodes_down,
                'nodesLvDown'     => $t_lv_nodes_down,
                'artnodesUp'    => $art_nodes_up,
                'artnodesDown'  => $art_nodes_down,
                'artlvnodesDown'  => $art_lv_nodes_down,
                'dualRadios'    => $t_nodes_dual_radio,
                'singleRadios'  => $t_nodes_single_radio,
                'clientsNow'    => $client_count_now,
                'clientsPrevious' => $client_count_previous,
                'dataUsage'    => $data_usage,
                'clienstDelta'  => $clientsDelta,
                'clientsSlope'  => $clients_slope,
				'uptimhistpct'	=> $uptimhistpct_current,
                'treeLevel'     => $tree_level,
                'rollupData'    => $roll_up_data,
				'mesh_id_list'	=> $s_mesh_list
                
            ],
            '_serialize'    => array('success','items','metaData')
        ));
        
        
        /* $this->set(array(
            'success'       => true,
            'data'          => $items,
            '_serialize'    => array('success','data')
        ));
		*/
    }
    
    private function formatted_bytes($bytes){

        $ret_val=$bytes;
        if($bytes >= 1024){
            $ret_val = round($bytes/1024,2)."K";
        }
        if($bytes >= (1024*1024)){
            $ret_val = round($bytes/1024/1024,2)."M";
        }
         if($bytes >= (1024*1024*1204)){
            $ret_val = round($bytes/1024/1024/1024,2)."G";
        }
        if($bytes >= (1024*1024*1204*1204)){
            $ret_val = round($bytes/1024/1024/1024/1024,2)."T";
        }
         if($bytes >= (1024*1024*1204*1204*1204)){
            $ret_val = round($bytes/1024/1024/1024/1024/1024,2)."P";
        }
        return $ret_val;
    }
    
    
    private function _get_dead_after($mesh_id){
		Configure::load('MESHdesk');
		$data 		= Configure::read('common_node_settings'); //Read the defaults
		$dead_after	= $data['heartbeat_dead_after'];
		$n_s = $this->Meshes->NodeSettings->find()->where(['NodeSettings.mesh_id' => $mesh_id])->first(); 
		
        if($n_s){
            $dead_after = $n_s->heartbeat_dead_after;
        }
		return $dead_after;
	}
    
	private function _secondsToTime($seconds) {
		$dtF = new \DateTime('@0');
		$dtT = new \DateTime("@$seconds");
		return $dtF->diff($dtT)->format('%a days, %h hours, %i minutes and %s seconds');
	}
}
