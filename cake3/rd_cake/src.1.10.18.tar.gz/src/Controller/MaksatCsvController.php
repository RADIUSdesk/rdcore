<?php

namespace App\Controller;
use App\Controller\AppController;

use Cake\Core\Configure;
use Cake\Core\Configure\Engine\PhpConfig;

use Cake\Utility\Inflector;
use Cake\I18n\FrozenTime;
use Cake\I18n\Time;
use Cake\Datasource\ConnectionManager;
use Cake\Event\Event;


class MaksatCsvController extends AppController{
  
    protected $base         = "Access Providers/Controllers/MaksatCsv/";   
    protected $main_model   = 'Meshes';

    protected $dead_after   = 600; //Default
  
    public function initialize(){  
        parent::initialize();
        $this->loadModel('Meshes');
        $this->loadModel('Nodes');
        $this->loadModel('NodeStations');
        $this->loadModel('TreeTags'); 
        $this->loadModel('Users');    
        $this->loadComponent('Aa');
        $this->loadComponent('CommonQuery', [ //Very important to specify the Model
            'model'                     => 'Meshes',
            'no_available_to_siblings'  => false,
            'sort_by'                   => 'Meshes.name'
        ]); 
             
        $this->loadComponent('JsonErrors'); 
        $this->loadComponent('TimeCalculations'); 
         
        $data 		        = Configure::read('common_node_settings'); //Read the defaults
		$this->dead_after	= $data['heartbeat_dead_after'];
           
    }


     public function exportMeshCsv(){

        $this->autoRender   = false;
        $this->main_model = 'Meshes';
        //__ Authentication + Authorization __      
        $user = $this->Aa->user_for_token($this);
        if(!$user){   //If not a valid user
            return;
        }
        $query              = $this->{$this->main_model}->find(); 
        $this->CommonQuery->build_common_query($query,$user,['Users','RollingLastHours','RollingLastDays','RollingLastSevenDays','RollingLastThirtyDays']);
        //===== PAGING (MUST BE LAST) ======
        $limit  = 6000;   //Defaults
        $page   = 1;
        $offset = 0;
        if(isset($this->request->query['limit'])){
            $limit  = $this->request->query['limit'];
            $page   = $this->request->query['page'];
            $calcOffset = ($page * $limit) - $limit;
            $offset =  $calcOffset < 0 ? 0 : $calcOffset;
        }

		$query->page($page);
        $query->limit($limit);
        $query->offset($offset);
        $q_r                = $query->all();

        //Create file
        $this->ensureTmp();     
        $tmpFilename    = TMP . $this->tmpDir . DS .  strtolower( Inflector::pluralize($this->modelClass) ) . '-' . date('Ymd-Hms') . '.csv';
        $fp             = fopen($tmpFilename, 'w');
		$rolling_table = 'rolling_last_hours';

        //Headings
		// From Vinod request 5/23/18
		// Columns: GP Name, GP Node Count, GP Online Node Count, GP Offline Node Count, GP Last Contact Time, GP Last Contact Time in Words
        $columns = ['GP Name','GP Node Count','GP Online Node Count','GP Offline Node Count','GP Last Contact Time','GP Last Contact Time in Words'];  
        $heading_line   = array();
        foreach($columns as $c){
            array_push($heading_line,$c);
        }
        
        fputcsv($fp, $heading_line,';','"');
        
        foreach($q_r as $i){
            $csv_line   = array();
			$last_contact = $i->{'last_contact'};
			if($last_contact !== null){
				$lc_words = $this->TimeCalculations->time_elapsed_string($last_contact);
			} else {
				$lc_words = '';
			}
			$node_count = 0;
			$nodes_up	= 0;
			$nodes_down	= 0;
			foreach($i->{"$rolling_table"} as $mrlx){
				$node_count	= $mrlx->tot_nodes;
				$nodes_up	= $mrlx->tot_nodes_up;
				$nodes_down	= $mrlx->tot_nodes_down;
			}
            array_push($csv_line,$i->name);
            array_push($csv_line, $node_count);
            array_push($csv_line, $nodes_up);
            array_push($csv_line, $nodes_down);
            array_push($csv_line, $last_contact);
            array_push($csv_line, $lc_words);
                  
            fputcsv($fp, $csv_line,';','"');
        }

        //Return results
        fclose($fp);
        $data = file_get_contents( $tmpFilename );
        $this->cleanupTmp( $tmpFilename );
        $this->RequestHandler->respondAs('csv');
        $this->response->download( strtolower( 'Meshes' ) . '.csv' );
        $this->response->body($data);
    } 
	// Example endpoint call: http://<site>/cake3/rd_cake/maksat-csv/export_node_csv.json?page=1&limit=25&token=<valid_token_value>
    public function exportNodeCsv()
    {
        $this->autoRender   = false;
        $this->main_model = 'Nodes';
        
        //__ Authentication + Authorization __
        $user = $this->Aa->user_for_token($this);
        if(!$user){   //If not a valid user
            return;
        }

        $query = $this->{$this->main_model}->find();

        $query->where(['Meshes.user_id IN' => $this->_get_user_ids_from_parents($user['id'])]);

        $this->CommonQuery->build_common_query($query,$user,['Meshes'], 'Nodes');
        $limit  = 6000;   //Defaults
        $page   = 1;
        $offset = 0;
        if(isset($this->request->query['limit'])){
            $limit  = $this->request->query['limit'];
            $page   = $this->request->query['page'];
            $calcOffset = ($page * $limit) - $limit;
            $offset =  $calcOffset < 0 ? 0 : $calcOffset;
        }

        $query->page($page);
        $query->limit($limit);
        $query->offset($offset);

        $q_r    = $query->all();
        //Create file
        $this->ensureTmp();     
        $tmpFilename    = TMP . $this->tmpDir . DS .  strtolower( 'Nodes' ) . '-' . date('Ymd-Hms') . '.csv';
        $fp             = fopen($tmpFilename, 'w');
        //Headings
		// From Vinod request 5/23/18
		// Columns: Node Name, GP Name (the GP the node belongs to), Node Online/Offline Status, Node Last Contact Time, Node Last Contact Time in Words
        $columns = ['Node Name','Node MAC','Node GP Name','Node Online/Offline','Node Last Contact Time','Node Last Contact Time in Words'];  
        $heading_line   = array();
        foreach($columns as $c){
            array_push($heading_line,$c);
        }
        $mesh_id = 0;
		$mesh_name = "Mesh Name";
        fputcsv($fp, $heading_line,';','"');
        foreach($q_r as $i){
            $csv_line   = array();
			$last_contact = $i->{'last_contact'};
			if($i->{'mesh_id'} !== $mesh_id){
				$mesh_rs = $this->Meshes->find()->where(['Meshes.id' => $i->{'mesh_id'}])->first();
				if($mesh_rs){
					$mesh_name = $mesh_rs->name;
				} else {
					$mesh_name = "Mesh Name";
				}
			}
			if($last_contact !== null){
				$lc_words = $this->TimeCalculations->time_elapsed_string($last_contact);
			} else {
				$lc_words = '';
			}
            array_push($csv_line,$i->name);
            array_push($csv_line,$i->mac);
            array_push($csv_line,$mesh_name);
            array_push($csv_line, $this->_get_node_status($i->id,$i->mesh_id));
            array_push($csv_line, $last_contact);
            array_push($csv_line, $lc_words);
                  
            fputcsv($fp, $csv_line,';','"');
        }

        //Return results
        fclose($fp);
        $data = file_get_contents( $tmpFilename );
        $this->cleanupTmp( $tmpFilename );
        $this->RequestHandler->respondAs('csv');
        $this->response->download( strtolower( "Nodes" ) . '.csv' );
        $this->response->body($data);

	}

	
    public function login(){

        $this->loadComponent('Auth', [
            'authenticate' => [
                'Form' => [
                    'userModel' => 'Users',
                    'fields' => ['username' => 'username', 'password' => 'password'],
                    'passwordHasher' => [
                        'className' => 'Fallback',
                        'hashers' => [
                            'Default',
                            'Weak' => ['hashType' => 'sha1']
                        ]
                    ]
                ]
            ]
        ]);

        if ($this->request->is('post')) {
            $user = $this->Auth->identify();
            if ($user){
                //We can get the detail for the user
                $u = $this->Users->find()->contain(['Groups'])->where(['Users.id' => $user['id']])->first();

                $data = [];

                // added for rolling token; enhanced security
                //FIXME Bring it back later with Config option -> Makes it hard to colaborate and troubleshoot
                // --- BEGIN ---
                // $u->set('token',''); //Setting it to '' will trigger a new token generation
                //  $this->Users->save($u);
                //  $data['token']  = $u->get('token');
                // --- END ---
                if($u->token ==''){
                     $u->set('token',''); //Setting it to '' will trigger a new token generation
                     $this->Users->save($u);
//                     $data['token']  = $u->get('token');
                }

                $data = $this->_get_user_detail($u);

                $this->set(array(
                    'data'          => $data,
                    'success'       => true,
                    '_serialize' => array('data','success')
                ));

            }else{

                $this->set(array(
                    'errors'        => array('username' => __('Type the username again'),'password'=> __('Type the password again')),
                    'success'       => false,
                    'message'       => __('Authentication failed'),
                    '_serialize' => array('errors','success','message')
                ));

            }
        }
    }

    public function logout(){
//        $user = $this->Aa->user_for_token($this);
//        if(!$user){   //If not a valid user
//            return;
//        }
//
////        $u = $this->{'Users'}->find()->contain(['Groups'])->where(['Users.id' => $user['id']])->first();
//
//        $this->{'Users'}->query()
//            ->update()
//            ->set(['token' => ''])
//            ->where(['id' => $user['id']])
//            ->execute();
        //___ FINAL PART ___
        $this->set(array(
            'success' => true,
            '_serialize' => array('success')
        ));
    }
    
    public function getToken(){

        $this->loadComponent('Auth', [
            'authenticate' => [
                'Form' => [
                    'userModel' => 'Users',
                    'fields' => ['username' => 'username', 'password' => 'password'],
                    'passwordHasher' => [
                        'className' => 'Fallback',
                        'hashers' => [
                            'Default',
                            'Weak' => ['hashType' => 'sha1']
                        ]
                    ]
                ]
            ]
        ]);

        if ($this->request->is('post')) {
            $user = $this->Auth->identify();
            if ($user){

                $this->set(array(
                    'data'          => ['token' => $user['token'],'username' =>$user['username']],
                    'success'       => true,
                    '_serialize' => array('data','success')
                ));

            }else{

                $this->set(array(
                    'errors'        => array('username' => __('Type the username again'),'password'=> __('Type the password again')),
                    'success'       => false,
                    'message'       => __('Authentication failed'),
                    '_serialize' => array('errors','success','message')
                ));

            }
        }else{
            $this->set(array(
                'errors'        => array('username' => __('Required'),'password'=> __('Required')),
                'success'       => false,
                'message'       => __('HTTP POST Required -> Authentication failed'),
                '_serialize' => array('errors','success','message')
            ));
            return;
        }
    }
    
    public function verifyToken(){

        if((isset($this->request->query['token']))&&($this->request->query['token'] != '')){

            $token  = $this->request->query['token'];
            $user   = $this->Users->find()->contain(['Groups'])->where(['Users.token' => $token])->first();

            if(!$user){
                $this->set(array(
                    'errors'        => array('token'=>'invalid'),
                    'success'       => false,
                    '_serialize'    => array('errors','success')
                ));

            }else{

                $data = $this->_get_user_detail($user);
                $this->set(array(
                    'data'          => $data,
                    'success'       => true,
                    '_serialize'    => array('data','success')
                ));
            }

        }else{

            $this->set(array(
                'errors'        => array('token'=>'missing'),
                'success'       => false,
                '_serialize'    => array('errors','success')
            ));
        }

    }

    private function formatted_bytes($bytes){

        $ret_val=$bytes;
        if($bytes >= 1024){
            $ret_val = round($bytes/1024,0)." Kb";
        }
        if($bytes >= (1024*1024)){
            $ret_val = round($bytes/1024/1024,0)." Mb";
        }
         if($bytes >= (1024*1024*1204)){
            $ret_val = round($bytes/1024/1024/1024,0)." Gb";
        }
        if($bytes >= (1024*1024*1204*1204)){
            $ret_val = round($bytes/1024/1024/1024,0)." Tb";
        }
         if($bytes >= (1024*1024*1204*1204*1204)){
            $ret_val = round($bytes/1024/1024/1024,0)." Pb";
        }
        return $ret_val;
    }

    private function _get_dead_after($mesh_id){
		$dead_after	= $this->dead_after;
		//FIXME A CSC Hack to make it faster
		///$n_s = $this->Meshes->NodeSettings->find()->where(['NodeSettings.mesh_id' => $mesh_id])->first(); 
        ///if($n_s){
        ///    $dead_after = $n_s->heartbeat_dead_after;
        ///}
		return $dead_after;
	}

    private function _tree_tags($entity){
        $tag_path = 'not_tagged';
        if($entity->tree_tag_id !== null){
            //Make sure the TreeTag exists
            $tt_check = $this->{'TreeTags'}->find()->where(['TreeTags.id' => $entity->tree_tag_id])->first();
            if($tt_check){
                $tag_path = '';
                $crumbs = $this->{'TreeTags'}->find('path', ['for' => $entity->tree_tag_id]);
                foreach ($crumbs as $crumb) {
                    if($crumb->id == $entity->tree_tag_id){
                        $tag_path = $tag_path.$crumb->name;
                    }else{
                        $tag_path = $tag_path.$crumb->name . ' > ';
                    }
                }
            }else{
                $tag_path = "orphaned";
            }
        }
        return $tag_path;
    }

    private function _get_user_detail($user){

        return array(
            'user' => [
                'id' => $user->id,
                'username' => $user->username,
                'group' => $user->group->name,
                'token' => $user->token
            ]
        );

    }

    private function _get_user_ids_from_parents($user_id){
        $query = $this->{'Users'}->find();
        $query->select(['id','parent_id']);

        $q_r = $query->all();

        $user_ids = [];

        if($q_r){

            foreach ($q_r as $uid){
                if($this->_is_root($user_id)){
                    array_push($user_ids, $uid->id);
                } elseif ($uid->parent_id != '' && ($uid->id == $user_id or $uid->parent_id == $user_id)){
                    array_push($user_ids, $uid->id);
                }

            }
        } else {
            array_push($user_ids, $user_id);
        }

        return $user_ids;
    }

    private function _is_root($user_id){
        $qt = $this->{'Users'}->find()
                    ->select(['parent_id'])
                    ->where(['id' => $user_id])
                    ->first();
        if($qt){
            return $qt->parent_id == '' ? true : false;
        }
        return false;
    }

    private function _get_node_status($node_id, $mesh_id){
        $dead_after = $this->_get_dead_after($mesh_id);
        $query = $this->{'Nodes'}->find();
        $query->where(['id' => $node_id]);
        $query->where(['UNIX_TIMESTAMP() - ' . $dead_after . ' <='  => 'UNIX_TIMESTAMP(last_contact)']);
        $n_s = $query->first();

        return (empty($n_s) or is_null($n_s)) ? 'down' : 'up';
    }

    private function _build_ns_api_sorting($query, $user, $model){

        $query->join([
            'n' => [
                'table' => 'nodes',
                'type' => 'LEFT',
                'conditions' => 'n.id = NodeStations.node_id',
            ],
            'm' => [
                'table' => 'meshes',
                'type' => 'LEFT',
                'conditions' => 'm.id = n.mesh_id',
            ]
        ]);

        // Add Sorting Query

        // Filter Query
        $this->_api_ns_filter($query, $model, $user);

        $query->select(['NodeStations.id', 'NodeStations.node_id', 'n.ip', 'NodeStations.mac', 'NodeStations.vendor', 'NodeStations.created', 'NodeStations.modified', 'data_sent' => $query->func()->sum('NodeStations.tx_bytes'), 'data_received' => $query->func()->sum('NodeStations.rx_bytes')]);

        $query->group(['NodeStations.node_id', 'NodeStations.mac', 'NodeStations.vendor','NodeStations.mesh_entry_id']);

        // Sort Query
        $this->_api_ns_sort($query,$model,'node_id');

    }

    private function _api_ns_filter($query, $model, $user){

        $duration = isset($this->request->query['duration']) ? $this->_time_string_parser($this->request->query['duration']) : $this->_time_string_parser();

         // Default
        $modified = time() - $duration;

        $where_clause   = [];

        if(isset($this->request->query['filter'])){
            $filter = json_decode($this->request->query['filter']);

            foreach($filter as $f){

                //Strings (like)
                if($f->operator == 'like'){
                    $col = $model.'.'.$f->property;
                    array_push($where_clause,array("$col LIKE" => '%'.$f->value.'%'));
                }

                //Bools
                if($f->operator == '=='){
                    $col = $model.'.'.$f->property;
                    array_push($where_clause,array("$col" => $f->value));
                }

                if($f->operator == 'in'){
                    $list_array = array();
                    foreach($f->value as $filter_list){
                        $col = $model.'.'.$f->property;
                        array_push($list_array,array("$col" => "$filter_list"));
                    }
                    array_push($where_clause,array('OR' => $list_array));
                }

                if(($f->operator == 'gt')||($f->operator == 'lt')||($f->operator == 'eq')){
                    //date we want it in "2018-03-12"
                    $col = $model.'.'.$f->property;
                    $date_array = ['created', 'modified'];
                    if(in_array($f->property,$date_array)){
                        if($f->operator == 'eq'){
                            array_push($where_clause,array("DATE($col)" => $f->value));
                        }

                        if($f->operator == 'lt'){
                            array_push($where_clause,array("DATE($col) <" => $f->value));
                        }
                        if($f->operator == 'gt'){
                            array_push($where_clause,array("DATE($col) >" => $f->value));
                        }
                    }else{
                        if($f->operator == 'eq'){
                            array_push($where_clause,array("$col" => $f->value));
                        }

                        if($f->operator == 'lt'){
                            array_push($where_clause,array("$col <" => $f->value));
                        }
                        if($f->operator == 'gt'){
                            array_push($where_clause,array("$col >" => $f->value));
                        }
                    }
                }
            }
        }

        // -- CSC Specific filter --
        if(isset($this->request->query['tree_tag_id'])){
            $tree_tag_id = $this->request->query['tree_tag_id'];
            //$tree_tag_id = 269;
            if($tree_tag_id !== '0'){ //The root value (0)we simply ignore = no filter

                //See which level we are at
                $tree_tags = TableRegistry::get('TreeTags');

                $children  = $tree_tags->find('children', ['for' => $tree_tag_id]);
                $tree_tag_clause = [];
                foreach($children as $i){
                    array_push($tree_tag_clause,array('Meshes.tree_tag_id' => $i->id));
                }

                if(count($tree_tag_clause) > 0){
                    array_push($where_clause,array('OR' => $tree_tag_clause));
                }else{
                    array_push($where_clause,['Meshes.tree_tag_id' => $tree_tag_id]);
                }

            }
        }
        // -- END CSC Specifi filter --
//        if(isset($this->request->query['interval'])){
//            $interval = $this->request->query['interval'];
//        }
        array_push($where_clause, [
            ['UNIX_TIMESTAMP(NodeStations.modified) >' => $modified],
            ['m.user_id IN' => $this->_get_user_ids_from_parents($user['id'])]
        ]);

        $query->where($where_clause);
    }

    private function _api_ns_sort($query, $model, $default_column = 'name'){

        //Defaults
        $sort   = $model.'.'.$default_column;
        $dir    = 'ASC';

        if(isset($this->request->query['sort'])){
            if($this->request->query['sort'] == 'owner'){
                $sort = 'Users.username';
            }elseif(
                ($this->request->query['sort'] == 'nodes_down')||
                ($this->request->query['sort'] == 'nodes_up')
            ){
                $sort = $model.'.last_contact';
            }else{
                $sort = $model.'.'.$this->request->query['sort'];
            }

            //Special case for IP Address
            if($this->request->query['sort'] == 'static_ip'){
                $sort = 'INET_ATON(static_ip)';
            }
            $dir  = isset($this->request->query['dir']) ? $this->request->query['dir'] : $dir;
        }
        $query->order([$sort => $dir]);
//        $query->order(['NodeStations.node_id' => 'ASC']);
    }

    private function _get_model_name($hardare_model_key){
        Configure::config('default_cake2', new PhpConfig('/usr/share/nginx/html/cake2/rd_cake/Config/'));
        Configure::load('MESHdesk', 'default_cake2');
        $hardware = Configure::read('hardware');

        if(count($hardware)){
            foreach ($hardware as $hw) {
                if($hw['id'] == $hardare_model_key){
                    return $hw['name'];
                    break;
                }
            }
        } else {
            return $hardare_model_key;
        }

    }

    private function _time_string_parser($string = null){
        $duration = 24 * 60 * 60; // Default to 24 Hours

        $numbers = [];
        $letter = [];

        if(is_null($string)){
            return $duration;
        }

        $string_array = str_split($string);

        for($x = 0; $x< count($string_array); $x++){
            if(is_numeric($string_array[$x])){
                array_push($numbers,$string_array[$x]);
            } else {
                array_push($letter,$string_array[$x]);
            }
        }

        if(count($letter) > 1){
            return $duration;
        }

        $letter = implode($letter);
        $numbers = implode($numbers);
        $numeric_number = (int) $numbers;

        switch ($letter) {
            case 'm':
                $duration = 60 * $numeric_number;
                break;
            case 'h':
                $duration = 60 * 60 * $numeric_number;
                break;
            case 'd':
                $duration = 24 * 60 * 60 * $numeric_number;
                break;
            case 'w':
                $duration = 7 * 24 * 60 * 60 * $numeric_number;
                break;
            case 'M':
                $duration = 4 * 7 * 24 * 60 * 60 * $numeric_number;
                break;
            case 'y':
                $duration = 12 * 4 * 7 * 24 * 60 * 60 * $numeric_number;
                break;
            default :
                $duration = 24 * 60 * 60;
        }

        return $duration;
    }

    private function _get_node_uptime_downtime($node_id, $dur = null){
        $data = [];
        // Determine if node was never contacted
        $node_contact = $this->Nodes->find()->where(['Nodes.id' => $node_id, 'Nodes.last_contact IS' => null]);
        if($node_contact->count() > 0 ){
            $data['uptime_mins'] = 0;
            $data['downtime_mins'] = 0;

            return $data;
        }
        $duration = is_null($dur) ? (1440 * 60) : $dur;
        $current_time = time();
        $time_frame = $current_time - $duration;
		
        $this->loadModel('NodeUptmHistories');

        $query = $this->NodeUptmHistories->find()->contain(['Nodes']);

        $query->where(['NodeUptmHistories.node_id' => $node_id, 'UNIX_TIMESTAMP(NodeUptmHistories.modified) >=' => $time_frame]);

        $query->order(['NodeUptmHistories.created' => 'ASC']);

        $nuh_count = $query->count();
        // Add a check for a strange situation
        if($nuh_count == 0){
            $data['uptime_mins'] = 0;
            $data['downtime_mins'] = 0;

            return $data;
        }

        $q_r = $query->all();

        $nuh = 0;

//        die(var_dump($q_r));
        $node_up_time = 0;
        $node_down_time = 0;

        if($nuh_count > 0) {
			foreach ($q_r as $itm) {
				$diff = 0;
                $node_state = (int) $itm->node_state;
                $report_date = strtotime($itm->report_datetime);
                $state_date = strtotime($itm->state_datetime);
               if($nuh == 0){ // First one
                    $diff = $state_date - $time_frame;

                    if($diff > 0){
                        // Positive $diff, count as Downtime
                        $node_down_time = $node_down_time + $diff;
                        $diff = 0;
                    }
                }

                // If it is the only record
                if($nuh == 0 && ( $nuh == ($nuh_count - 1)) ){
                    $diff = $diff + ($report_date - $state_date) + ($current_time - $report_date);
                }

                if($nuh > 0 && ($nuh <= ($nuh_count - 1))){ // middle times
                    $diff = $diff + $report_date - $state_date;
                }

                if($nuh != 0 && ($nuh == ($nuh_count - 1))){ // last One
                    $diff = $diff + $current_time - $report_date;
                }

                if($node_state == 1){
                    $node_up_time = $node_up_time + $diff;
//                    die(var_dump($diff));
                } else {
                    $node_down_time = $node_down_time + $diff;
//                    die(var_dump($node_down_time));
                }

                $nuh++;
            }
        }

        $node_up_time = $node_up_time / 60;
        $node_down_time = $node_down_time / 60;
        $data['uptime_mins'] = $node_up_time;
        $data['downtime_mins'] = $node_down_time;

        return $data;
    }


}
