<?php

/*
{
    aRecordOnly:boolean
    adRemove:boolean
    blockAll:boolean
    blockCategoryArr:[
        string
    ]
    blockCovertChan:boolean
    blockDnsRebinding:boolean
    blockMailerWorm:boolean
    blockUnclass:boolean
    btEtime:string
    btStime:string
    copyId:integer (int32)
    description:string
    disableApplicationControl:boolean
    disableProxy:boolean
    enableFilter:boolean
    logOnly:boolean
    maxDomainLen:integer (int32)
    operatorName:string
    points:integer (int32)
    safeMode:integer (int32)
    safeModeWithoutYoutube:boolean
    systemFlag:boolean
}

*/

namespace App\Controller;
use App\Controller\AppController;

use Cake\Core\Configure;
use Cake\Core\Configure\Engine\PhpConfig;

use Cake\Http\Client;

class DnsDeskUsersController extends AppController{

    protected $proto        = "http";
    protected $server       = "87.98.135.120";
    protected $auth         = ['username' => 'Chrispy1', 'password' => 'magic1023'];
    protected $boolChecks   = [
        'systemFlag',       'safeModeWithoutYoutube',   'logOnly',      'enableFilter',
        'disableProxy',     'disableApplicationControl','blockUnclass', 'blockMailerWorm',
        'blockDnsRebinding','blockCovertChan',          'blockAll',     'adRemove',
        'aRecordOnly'
    ];
    
    protected $categories = array (
  0 => 
  array (
    'id' => 1,
    'name' => 'Ads',
    'description' => 'Advertising, online marketing.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  1 => 
  array (
    'id' => 2,
    'name' => 'Alcohol/Tobacco',
    'description' => 'Alcohol and tobacco related sites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  2 => 
  array (
    'id' => 3,
    'name' => 'Astrology',
    'description' => 'Astrology, fortune telling, palm reading.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  3 => 
  array (
    'id' => 4,
    'name' => 'Blog',
    'description' => 'Blog and personal websites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  4 => 
  array (
    'id' => 5,
    'name' => 'Business/Service',
    'description' => 'General business or company websites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  5 => 
  array (
    'id' => 6,
    'name' => 'CDN',
    'description' => 'Content delivery network sites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  6 => 
  array (
    'id' => 7,
    'name' => 'Car/Vehicle',
    'description' => 'Car, bike, boat, airplane and other vehicle related websites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  7 => 
  array (
    'id' => 8,
    'name' => 'Chat',
    'description' => 'Sites for chatting and related softwares.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  8 => 
  array (
    'id' => 9,
    'name' => 'Computer/Technology',
    'description' => 'Software, hardware, computer and mobile phone.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  9 => 
  array (
    'id' => 10,
    'name' => 'Cooking/Food',
    'description' => 'Cooking, food related information and restaurants.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  10 => 
  array (
    'id' => 11,
    'name' => 'Dating',
    'description' => 'Dating sites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  11 => 
  array (
    'id' => 12,
    'name' => 'Download',
    'description' => 'Software download sites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  12 => 
  array (
    'id' => 13,
    'name' => 'Drugs',
    'description' => 'Legal or illegal drugs and online pharmacies.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  13 => 
  array (
    'id' => 14,
    'name' => 'Education',
    'description' => 'Educational institutes, libraries.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  14 => 
  array (
    'id' => 15,
    'name' => 'Entertainment',
    'description' => 'Movie, TV, radio, comics.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  15 => 
  array (
    'id' => 16,
    'name' => 'Fashion/Beauty',
    'description' => 'Fashion and beauty, clothes, cosmetics, style.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  16 => 
  array (
    'id' => 17,
    'name' => 'File Hosting',
    'description' => 'File hosting, cloud storage.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  17 => 
  array (
    'id' => 18,
    'name' => 'Finance',
    'description' => 'Banking, insurance and other financial services.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  18 => 
  array (
    'id' => 19,
    'name' => 'Forum',
    'description' => 'Forum and Internet communities.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  19 => 
  array (
    'id' => 20,
    'name' => 'Gambling',
    'description' => 'Gambling or lottery websites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  20 => 
  array (
    'id' => 21,
    'name' => 'Game',
    'description' => 'Computer game, console game, online game, board game and game reviews.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  21 => 
  array (
    'id' => 22,
    'name' => 'Government',
    'description' => 'Goverment owned websites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  22 => 
  array (
    'id' => 23,
    'name' => 'Hacking',
    'description' => 'Websites providing hacking related softwares and information.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  23 => 
  array (
    'id' => 25,
    'name' => 'Health/Medical',
    'description' => 'Health and medical information, hospitals.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  24 => 
  array (
    'id' => 26,
    'name' => 'Hobby/Recreation',
    'description' => 'Collecting and pet related information.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  25 => 
  array (
    'id' => 27,
    'name' => 'Home/Gardening',
    'description' => 'Home improvement, home safety, decoration, gardening.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  26 => 
  array (
    'id' => 28,
    'name' => 'Hunting/Fishing',
    'description' => 'Hunting and fishing related sites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  27 => 
  array (
    'id' => 29,
    'name' => 'Job',
    'description' => 'Finding employment or finding employer and employee.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  28 => 
  array (
    'id' => 31,
    'name' => 'Knowledge',
    'description' => 'General knowledge, history, science, howto and tutorial.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  29 => 
  array (
    'id' => 32,
    'name' => 'Learning',
    'description' => 'Online lecture, learning and training courses.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  30 => 
  array (
    'id' => 33,
    'name' => 'Legal',
    'description' => 'Law firms, discussions on legal issues.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  31 => 
  array (
    'id' => 34,
    'name' => 'Military',
    'description' => 'Military websites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  32 => 
  array (
    'id' => 35,
    'name' => 'Misc',
    'description' => 'Not belongs to any other categories but not a porn site.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  33 => 
  array (
    'id' => 36,
    'name' => 'Music',
    'description' => 'Music, lyrics, band and musicians.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  34 => 
  array (
    'id' => 37,
    'name' => 'News/Magazine',
    'description' => 'News, magazine, weather.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  35 => 
  array (
    'id' => 39,
    'name' => 'Phishing/Malware',
    'description' => 'Phishing, malware, spyware, dangerous sites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  36 => 
  array (
    'id' => 40,
    'name' => 'Politics',
    'description' => 'Political parties or talking about politics.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  37 => 
  array (
    'id' => 41,
    'name' => 'Porn',
    'description' => 'Porn sites or websites serving sexual materials.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  38 => 
  array (
    'id' => 42,
    'name' => 'Proxy/Anonymizer',
    'description' => 'Proxy or anonymizer and other tools for circumventing filtering.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  39 => 
  array (
    'id' => 43,
    'name' => 'Real Estate',
    'description' => 'Renting, buying, or selling real estate or properties.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  40 => 
  array (
    'id' => 44,
    'name' => 'Reference',
    'description' => 'Dictionary, map, translation, IP lookup, document templates, materials for learning.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  41 => 
  array (
    'id' => 45,
    'name' => 'Religion',
    'description' => 'Churches, temples, houses of worship, talking about religious matters.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  42 => 
  array (
    'id' => 46,
    'name' => 'Search Engine',
    'description' => 'Websearch engines and directory services, website information, ranking.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  43 => 
  array (
    'id' => 47,
    'name' => 'Shopping',
    'description' => 'Online shopping and department stores, retail stores.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  44 => 
  array (
    'id' => 48,
    'name' => 'Social Networking',
    'description' => 'Social networking sites.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  45 => 
  array (
    'id' => 49,
    'name' => 'Sports',
    'description' => 'Sports and martial arts.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  46 => 
  array (
    'id' => 50,
    'name' => 'Tracker',
    'description' => 'Tracking user activity.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  47 => 
  array (
    'id' => 51,
    'name' => 'Travel',
    'description' => 'Travel and vacation, hotels, airline tickets.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  48 => 
  array (
    'id' => 52,
    'name' => 'URL Shortener',
    'description' => 'URL shortener services.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  49 => 
  array (
    'id' => 53,
    'name' => 'Violence',
    'description' => 'Websites advocating violence, haterism, racism and other crimes.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  50 => 
  array (
    'id' => 54,
    'name' => 'Warez',
    'description' => 'Illegal download and torrents, piracy.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  51 => 
  array (
    'id' => 55,
    'name' => 'Weapon',
    'description' => 'Sales, reviews, or talking about weapons such as guns, knives.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  52 => 
  array (
    'id' => 56,
    'name' => 'Web Hosting',
    'description' => 'Web hosting, server hosting, domain registration.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
  53 => 
  array (
    'id' => 57,
    'name' => 'Webmail',
    'description' => 'Web based email services.',
    'domainList' => 
    array (
    ),
    'systemFlag' => false,
    'checkFlag' => false,
    'domainCount' => 0,
    'domainLine' => '',
  ),
);
    
    public function initialize(){  
        parent::initialize();
        $this->loadComponent('Aa');
        $this->loadComponent('GridButtons'); 
    }
    
    private function _prep_auth(){

        if(isset($this->request->query['operator_name'])){ 
            $this->auth['username'] = $this->request->query['operator_name'];   
        }
    }
     
    public function index(){ 
        $this->_prep_auth(); 
        $http = new Client();     
        $base = $this->proto.'://'.$this->server;
        
        $response = $http->get("$base/rest/user/list",
        [], 
        [
            'auth' => $this->auth,
            'type' => 'json'
        ]);
        
        $this->set(array(
            'items' => $response->json,
            'success' => true,
            '_serialize' => array('items','success')
        ));
    }
    
    public function categoriesList(){
        $this->set(array(
            'items' => $this->categories,
            'success' => true,
            '_serialize' => array('items','success')
        ));
    }
    
    public function view(){
    
        $http = new Client();
        $base = $this->proto.'://'.$this->server;
        
        $response = $http->get("$base/rest/user/2",
        [], 
        [
            'auth' => $this->auth
        ]);
    
        $data = $response->getStatusCode();
        $data = $response->json;
        
        $this->set(array(
            'items' => $data,
            'success' => true,
            '_serialize' => array('items','success')
        )); 
    }
    
    public function add(){
    
        $user = $this->Aa->user_for_token($this);
        if(!$user){   //If not a valid user
            return;
        }
        
        foreach($this->boolChecks as $i){
            if(isset($this->request->data[$i])){
                $this->request->data[$i] = 1;
            }else{
                $this->request->data[$i] = 0;
            }
        }
        
        $block_cat = [];  
        foreach(array_keys($this->request->data)as $key){
            if(preg_match('/^cat_/',$key)){
                $number = str_replace("cat_","","$key");
                array_push($block_cat, $number);  
            }
        } 
        $this->request->data['blockCategoryArr'] = $block_cat;
    
        $http = new Client();
        $base = $this->proto.'://'.$this->server; 
        $response = $http->post("$base/rest/user",
        json_encode($this->request->data), 
        [
            'auth' => $this->auth,
            'type' => 'json'
        ]);
        
        $data = $response->getStatusCode();
        
        $this->set(array(
            'items' => $data,
            'success' => true,
            '_serialize' => array('items','success')
        )); 
    }
    
     public function delete(){
     
        $user = $this->Aa->user_for_token($this);
        if(!$user){   //If not a valid user
            return;
        }
     
        $http = new Client();
        $base = $this->proto.'://'.$this->server;
        
        if(isset($this->request->data['id'])){   //Single item delete
            $id         =  $this->request->data['id'];
            $response   = $http->delete("$base/rest/user/".$id,[], 
            [
                'auth' => $this->auth
            ]);
            
        }else{                          //Assume multiple item delete
            foreach($this->request->data as $d){
               $id          = $d['id'];
               $response    = $http->delete("$base/rest/user/".$id,[], 
                [
                    'auth' => $this->auth
                ]);      
            }
        } 
        
        $data = $response->getStatusCode();
        
        $this->set(array(
            'items' => $data,
            'success' => true,
            '_serialize' => array('items','success')
        )); 
    }
    
    public function edit(){
    
        $user = $this->Aa->user_for_token($this);
        if(!$user){   //If not a valid user
            return;
        }
        
        foreach($this->boolChecks as $i){
            if(isset($this->request->data[$i])){
                $this->request->data[$i] = 1;
            }else{
                $this->request->data[$i] = 0;
            }
        }
        
        $block_cat = [];  
        foreach(array_keys($this->request->data)as $key){
            if(preg_match('/^cat_/',$key)){
                $number = str_replace("cat_","","$key");
                array_push($block_cat, $number);  
            }
        } 
        $this->request->data['blockCategoryArr'] = $block_cat;
    
        $http = new Client();
        $base = $this->proto.'://'.$this->server; 
        $id = $this->request->data['id'];
        $response = $http->put("$base/rest/user/".$id,
        json_encode($this->request->data), 
        [
            'auth' => $this->auth,
            'type' => 'json'
        ]);
        
        $data = $response->getStatusCode();
        $this->set(array(
            'items' => $data,
            'success' => true,
            '_serialize' => array('items','success')
        )); 
    }
    
    
    public function menuForGrid(){
    
        $user = $this->Aa->user_for_token($this);
        if(!$user){   //If not a valid user
            return;
        }
         
        $menu = $this->GridButtons->returnButtons($user,true,'basic_no_disabled'); 
        $this->set(array(
            'items'         => $menu,
            'success'       => true,
            '_serialize'    => array('items','success')
        ));
    }
}
