<?php

namespace App\Controller;

class DataUsagesController extends AppController {

    public $main_model        = 'DataUsage';
    protected $base     = "Access Providers/Controllers/DataUsage/";
    
    protected   $type       = false;
    protected   $item_name  = false;
    protected   $base_search = false;

    protected $fields   = [
        'data_in' => 'sum(UserStats.acctinputoctets)',
        'data_out' => 'sum(UserStats.acctoutputoctets)',
        'data_total' => 'sum(UserStats.acctoutputoctets) + sum(UserStats.acctinputoctets)',
    ];

    public function initialize()
    {
        parent::initialize();
        $this->loadModel('UserStats');
        $this->loadModel('Vouchers');
        $this->loadModel('PermanentUsers');
        $this->loadModel('Devices');

        $this->loadComponent('TimeCalculations');
        $this->loadComponent('Formatter');
    }

    public function clientUsageForRealm(){

        $data = [];

        $this->base_search = $this->_base_search();
        $today = date('Y-m-d', time());

        if($this->type == 'realm'){
            $data['daily']['top']   = $this->_getTopClients($today,'day');
            $data['weekly']['top']  = $this->_getTopClients($today,'week');
            $data['monthly']['top'] = $this->_getTopClients($today,'month');
        }


        $data['daily']['graph']     = $this->_getDailyGraph($today);
        $data['daily']['totals']    = $this->_getTotal($today,'day');

        $data['weekly']['totals']   = $this->_getTotal($today,'week');
        $data['weekly']['graph']    =  $this->_getWeeklyGraph($today);

        //_____ MONTHLY ___
        $data['monthly']['graph']   =  $this->_getMonthlyGraph($today);
        $data['monthly']['totals']  = $this->_getTotal($today,'month');

        if($this->type == 'nas_id'){
            $data['client_detail'] = $this->_getClientDetail();
        }


        $this->set([
            'data' => $data,
            'success' => true,
            '_serialize' => ['data','success']
        ]);
    }

    //--Read (the whole lot)
    public function usageForRealm() {

        $data = [];
           
        $this->base_search = $this->_base_search();
        $today = date('Y-m-d', time());
       
            
        //________ DAILY _________      
        
        //-- Only if $this->type = 'realm' do we need theser --
        if($this->type == 'realm'){
            $data['daily']['top_ten']   = $this->_getTopTen($today,'day');
            $data['weekly']['top_ten']  = $this->_getTopTen($today,'week');
            $data['monthly']['top_ten'] = $this->_getTopTen($today,'month');
            
            //Also the active sessions
            $active_sessions = [];
            $this->loadModel('Radaccts');
            $q_acct = $this->Radaccts->find()->where([
                'Radaccts.realm' => $this->item_name,
                'Radaccts.acctstoptime' => NULL
            ])->all();

            foreach($q_acct as $i){
                $online_time    = time()-strtotime($i->acctstarttime);
                $active         = true; 
                $online_human   = $this->TimeCalculations->time_elapsed_string($i->acctstarttime,false,true);
                array_push($active_sessions, [
                    'id'                => intval($i->radacctid),
                    'username'          => $i->username,
                    'callingstationid'  => $i->callingstationid,
                    'online_human'      => $online_human,
                    'online'            => $online_time
                ]);
            }
            $data['daily']['active_sessions'] = $active_sessions;
            
        }
        
        //____ Get some Dope on the user if it is a user
        if($this->type == 'user'){
            
            $data['user_detail'] = $this->_getUserDetail();
        
        }
        
        
        $data['daily']['graph']     = $this->_getDailyGraph($today);
        $data['daily']['totals']    = $this->_getTotal($today,'day');
        
        //______ WEEKLY ____
        $data['weekly']['totals']   = $this->_getTotal($today,'week');
        $data['weekly']['graph']    =  $this->_getWeeklyGraph($today);
        
        //_____ MONTHLY ___
        $data['monthly']['graph']   =  $this->_getMonthlyGraph($today);
        $data['monthly']['totals']  = $this->_getTotal($today,'month');
  
        $this->set([
            'data' => $data,
            'success' => true,
            '_serialize' => ['data','success']
        ]);
    }
     
    private function _getTotal($day,$span){
    
        $totals         = [];
        $where     = $this->base_search;
        
        if($span == 'day'){
            $slot_start     = "$day ".'00:00:00';
            $slot_end       = "$day ".'23:59:59';
        }
        
        if($span == 'week'){
            $pieces         = explode('-', $day);
            $start_day      = date('Y-m-d', strtotime('this week', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
            $pieces         = explode('-',$start_day);
            $end_day        = date('Y-m-d',strtotime('+7 day', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
              
            $slot_start     = "$start_day ".'00:00:00';
            $slot_end       = "$end_day ".'23:59:59';
        }
        
         if($span == 'month'){
            //$givenday = date("w", mktime(0, 0, 0, MM, dd, yyyy));
            $pieces         = explode('-', $day);
            $start_day      = date('Y-m-d', strtotime('first day of', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
            $end            = cal_days_in_month(CAL_GREGORIAN, $pieces[1], $pieces[0]); 
            $end_day        = date('Y-m-d',strtotime('+'.$end.' day', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
              
            $slot_start     = "$start_day ".'00:00:00';
            $slot_end       = "$end_day ".'23:59:59';
        }
        
        
        array_push($where, ['UserStats.timestamp >=' => $slot_start]);
        array_push($where, ['UserStats.timestamp <=' => $slot_end]);
        
        $q_r = $this->UserStats->find()->select($this->fields)->where($where)->first();

        $totals['type']         = $this->type;
        $totals['item_name']    = $this->item_name;
                 
        if($q_r){
            $totals['data_in']      = $q_r->data_in;
            $totals['data_out']     = $q_r->data_out;
            $totals['data_total']   = $q_r->data_total;
        } 
        return $totals;
    
    }

    private function _getTopClients($day,$span){

        $top        = [];
        $where = [];
        $conditions = $this->base_search;

        if($span == 'day'){
            $slot_start     = "$day ".'00:00:00';
            $slot_end       = "$day ".'23:59:59';
        }

        if($span == 'week'){
            $pieces         = explode('-', $day);
            $start_day      = date('Y-m-d', strtotime('this week', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
            $pieces         = explode('-',$start_day);
            $end_day        = date('Y-m-d',strtotime('+7 day', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));

            $slot_start     = "$start_day ".'00:00:00';
            $slot_end       = "$end_day ".'23:59:59';
        }

        if($span == 'month'){
            //$givenday = date("w", mktime(0, 0, 0, MM, dd, yyyy));
            $pieces         = explode('-', $day);
            $start_day      = date('Y-m-d', strtotime('first day of', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
            $end            = cal_days_in_month(CAL_GREGORIAN, $pieces[1], $pieces[0]);
            $end_day        = date('Y-m-d',strtotime('+'.$end.' day', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));

            $slot_start     = "$start_day ".'00:00:00';
            $slot_end       = "$end_day ".'23:59:59';
        }

        array_push($where,array('UserStats.timestamp >=' => $slot_start));
        array_push($where,array('UserStats.timestamp <=' => $slot_end));

        $fields = $this->fields;
        array_push($fields, 'UserStats.nasidentifier');

        $q_r = $this->UserStats->find()->select($fields)
                ->where($where)
                ->order(['data_total' => 'DESC'])
                ->group(['UserStats.nasidentifier'])
                ->all();

        $id = 1;
        foreach($q_r as $tt){
            $nas        = $tt->nasidentifier;
            array_push($top,
                [
                    'nasid'         => $nas,
                    'data_in'       => $tt[0]['data_in'],
                    'data_out'      => $tt[0]['data_out'],
                    'data_total'    => $tt[0]['data_total'],
                ]
            );
            $id++;
        }
        return $top;
    }

    private function _getTopTen($day,$span){
    
        $top_ten        = [];
        $where     = $this->base_search;
        
        if($span == 'day'){
            $slot_start     = "$day ".'00:00:00';
            $slot_end       = "$day ".'23:59:59';
        }
        
        if($span == 'week'){
            $pieces         = explode('-', $day);
            $start_day      = date('Y-m-d', strtotime('this week', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
            $pieces         = explode('-',$start_day);
            $end_day        = date('Y-m-d',strtotime('+7 day', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
              
            $slot_start     = "$start_day ".'00:00:00';
            $slot_end       = "$end_day ".'23:59:59';
        }
        
         if($span == 'month'){
            //$givenday = date("w", mktime(0, 0, 0, MM, dd, yyyy));
            $pieces         = explode('-', $day);
            $start_day      = date('Y-m-d', strtotime('first day of', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
            $end            = cal_days_in_month(CAL_GREGORIAN, $pieces[1], $pieces[0]); 
            $end_day        = date('Y-m-d',strtotime('+'.$end.' day', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
              
            $slot_start     = "$start_day ".'00:00:00';
            $slot_end       = "$end_day ".'23:59:59';
        }
        
        array_push($where, ['UserStats.timestamp >=' => $slot_start]);
        array_push($where, ['UserStats.timestamp <=' => $slot_end]);
        
        $fields = $this->fields;
        array_push($fields, 'UserStats.username');
        
        $q_r = $this->UserStats->find()->select($fields)
            ->where($where)
            ->order(['data_total' => 'DESC'])
            ->group(['UserStats.username'])
            ->all();
    
        $id = 1;
        foreach($q_r as $tt){
            $username = $tt['UserStat']['username'];
            array_push($top_ten, 
                [
                    'id'            => $id,
                    'username'      => $username,
                    'data_in'       => $tt->data_in,
                    'data_out'      => $tt->data_out,
                    'data_total'    => $tt->data_total,
                ]
            );
            $id++;
        } 
        return $top_ten;
    }
    
    private function _getDailyGraph($day){

        $items  = [];
        $start  = 0;
        $end    = 24;
        $base_search = $this->_base_search();

        while($start < $end){
            $slot_start  = "$day ".sprintf('%02d', $start).':00:00';
            $slot_end    = "$day ".sprintf('%02d', $start).':59:59';
            $start++;
        
            $where = $base_search;
            array_push($where, ['UserStats.timestamp >=' => $slot_start]);
            array_push($where, ['UserStats.timestamp <=' => $slot_end]);

            $q_r = $this->UserStats->find()->select($this->fields)->where($where)->first();

            if($q_r){
                $d_in   = $q_r->data_in;
                $d_out  = $q_r->data_out;
                array_push($items, ['id' => $start, 'time_unit' => $start, 'data_in' => $d_in, 'data_out' => $d_out]);
            }
        }
        return(['items' => $items]);
    }
    
    private function _getWeeklyGraph($day){

        $items          = [];
    
        //With weekly we need to find the start of week for the specified date
        $pieces     = explode('-', $day);
        $start_day  = date('Y-m-d', strtotime('this week', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));

        //Prime the days
        $slot_start = "$start_day 00:00:00";
        $slot_end   = "$start_day 59:59:59";
        $days       = ["Monday", "Tuesday","Wednesday", "Thusday", "Friday", "Saturday", "Sunday"];
        $count      = 1;

        $base_search = $this->_base_search();
       
        foreach($days as $d){

            $where = $base_search;
            array_push($where,['UserStats.timestamp >=' => $slot_start]);
            array_push($where,['UserStats.timestamp <=' => $slot_end]);

            $q_r = $this->UserStats->find()->select($this->fields)->where($where)->first();

            if($q_r){
                $d_in   = $q_r->data_in;
                $d_out  = $q_r->data_out;
                array_push($items, ['id' => $count, 'time_unit' => $d, 'data_in' => $d_in, 'data_out' => $d_out]);
            }

            //Get the nex day in the slots (we move one day on)
            $pieces     = explode('-',$start_day);
            $start_day  = date('Y-m-d',strtotime('+1 day', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
            $slot_start = "$start_day 00:00:00";
            $slot_end   = "$start_day 59:59:59";
            $count++;
        }
        return(['items' => $items]);
    }
    
    private function _getMonthlyGraph($day){

        $items          = [];
        //With weekly we need to find the start of week for the specified date
        //$givenday = date("w", mktime(0, 0, 0, MM, dd, yyyy));
        $pieces     = explode('-', $day);
        $start_day  = date('Y-m-d', strtotime('first day of', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));


        //Prime the days
        $slot_start = "$start_day 00:00:00";
        $slot_end   = "$start_day 59:59:59";

        $start  = 1;
        $end    = cal_days_in_month(CAL_GREGORIAN, $pieces[1], $pieces[0]); 
        $base_search = $this->_base_search();

        while($start <= $end){

            $where = $base_search;
            array_push($where, ['UserStats.timestamp >=' => $slot_start]);
            array_push($where, ['UserStats.timestamp <=' => $slot_end]);


            $q_r = $this->UserStats->find()->select($this->fields)->where($where)->first();

            if($q_r){
                $d_in   = $q_r->data_in;
                $d_out  = $q_r->data_out;

                array_push($items, ['id' => $start, 'time_unit' => $start, 'data_in' => $d_in, 'data_out' => $d_out]);
            }

            //Get the nex day in the slots (we move one day on)
            $pieces     = explode('-',$start_day);
            $start_day  = date('Y-m-d',strtotime('+1 day', mktime(0, 0, 0, $pieces[1],$pieces[2], $pieces[0])));
            $slot_start = "$start_day 00:00:00";
            $slot_end   = "$start_day 59:59:59";
            $start++;
        }
        return(['items' => $items]);
    }

    
    
    private function _base_search(){

        $type           = 'realm';
        $base_search    = [];
        $username       = $this->request->getQuery('username');
        $this->item_name= $username;

        if(null !== $this->request->getQuery('type')){
            $type = $this->request->getQuery('type');
            //Permanent users an vouchers
            if(($type == 'permanent')||($type == 'voucher')||($type == 'user')||($type == 'activity_viewer')){
                array_push($base_search, ['UserStats.username' => $username]);
        
            }
            //Devices
            if($type == 'device'){
                array_push($base_search, ['UserStat.callingstationid' => $username]);
            }
            //Realms
            if($type == 'realm'){
                $this->loadModel('Realms');

                $q_r = $this->Realms->find()->where(['Realms.id' => $username])->first();
                        
                if($q_r){ 
                    $realm_name = $q_r->name;
                    $this->item_name= $realm_name;
                    array_push($base_search, ['UserStats.realm' => $realm_name]);
                }
            }
            //Nas
            if($type == 'nas'){
                $this->loadModel('Nas');

                $q_r = $this->Nas->find()->where(['Nas.id' => $username])->first();
                if($q_r){ 
                    $nas_identifier = $q_r->nasidentifier;
                    $this->item_name= $nas_identifier;
                    array_push($base_search, ['UserStats.nasidentifier' => $nas_identifier]);
                }
            }
            
            //Dynamic clients
            if($type == 'dynamic_client'){
                $this->loadModel('DynamicClients');

                $q_r = $this->DynamicClients->find()->where(['DynamicClients.id' => $username])->first();

                if($q_r){
                    $this->item_name= $nas_identifier; 
                    $nas_identifier = $q_r->nasidentifier;
                    array_push($base_search, ['UserStats.nasidentifier' => $nas_identifier]);
                }
            } 
            
            $this->type = $type;    
        }
        return $base_search;
    }
    
    private function _getUserDetail(){
    
        $found = false;
    
        $user_detail = [];
        $username = $this->item_name;

        //Test to see if it is a Voucher
        $q_v = $this->Vouchers->find()->where(['Vouchers.name' => $username])->first();
       // print_r($q_v);
        if($q_v){
        
            $user_detail['username'] = $username;
            
            $user_detail['type']    = 'voucher';
            $user_detail['profile'] = $q_v->profile;
            $user_detail['created'] = $this->TimeCalculations->time_elapsed_string($q_v->created,false,false);
            $user_detail['status']  = $q_v->status;
            if($q_v->last_reject_time != null){
                $user_detail['last_reject_time'] = $this->TimeCalculations->time_elapsed_string($q_v->last_reject_time,false,false);
                $user_detail['last_reject_message'] = $q_v->last_reject_message;
            }
            
            if($q_v->last_accept_time != null){
                $user_detail['last_accept_time'] = $this->TimeCalculations->time_elapsed_string($q_v->last_accept_time,false,false);
            }
            
            if($q_v->data_cap != null){
                $user_detail['data_cap'] = $this->Formatter->formatted_bytes($q_v->data_cap);
            }
            
            if($q_v->data_used != null){
                $user_detail['data_used'] = $this->Formatter->formatted_bytes($q_v->data_used);
            }
            
            if($q_v->perc_data_used != null){
                $user_detail['perc_data_used'] = $q_v->perc_data_used;
            }
            
            if($q_v->time_cap != null){
                $user_detail['time_cap'] = $this->Formatter->formatted_seconds($q_v->time_cap);
            }
            
            if($q_v->time_used != null){
                $user_detail['time_used'] = $this->Formatter->formatted_seconds($q_v->time_used);
            }
            
            if($q_v->perc_time_used != null){
                $user_detail['perc_time_used'] = $q_v->perc_time_used;
            }
            $found = true;
   
        }
        
        if(!$found){
            $q_pu = $this->PermanentUsers->find()->where(['PermanentUsers.username' => $username])->first();

           // print_r($q_pu);
            if($q_pu){
            
                $user_detail['username']    = $username;
                $user_detail['type']        = 'user';
                $user_detail['profile']     = $q_pu->profile;
                $user_detail['created']     = $this->TimeCalculations->time_elapsed_string($q_pu->created,false,false);
                if($q_pu->last_reject_time != null){
                    $user_detail['last_reject_time'] = $this->TimeCalculations->time_elapsed_string($q_pu->last_reject_time,false,false);
                    $user_detail['last_reject_message'] = $q_pu->last_reject_message;
                }
            
                if($q_pu->last_accept_time != null){
                    $user_detail['last_accept_time'] = $this->TimeCalculations->time_elapsed_string($q_pu->last_accept_time,false,false);
                }
            
                if($q_pu->data_cap != null){
                    $user_detail['data_cap'] = $this->Formatter->formatted_bytes($q_pu->data_cap);
                }
            
                if($q_pu->data_used != null){
                    $user_detail['data_used'] = $this->Formatter->formatted_bytes($q_pu->data_used);
                }
            
                if($q_pu->perc_data_used != null){
                    $user_detail['perc_data_used'] = $q_pu->perc_data_used;
                }
            
                if($q_pu->time_cap != null){
                    $user_detail['time_cap'] = $this->Formatter->formatted_seconds($q_pu->time_cap);
                }
            
                if($q_pu->time_used != null){
                    $user_detail['time_used'] = $this->Formatter->formatted_seconds($q_pu->time_used);
                }
            
                if($q_pu->perc_time_used != null){
                    $user_detail['perc_time_used'] = $q_pu->perc_time_used;
                }
                $found = true;
            
            }
        
        }   
        return $user_detail;
    }
}
