<?php
/**
 * Created by G-edit.
 * User: dirkvanderwalt
 * Date: 06/09/2018
 * Time: 00:00
 */

namespace App\Controller;
use Cake\Core\Configure;

use Cake\Core\Configure\Engine\PhpConfig;

use Cake\Event\Event;
use Cake\Utility\Inflector;
use Cake\Utility\Text;

class NodesController extends AppController {

    protected $base = "Access Providers/Controllers/Nodes/";
    protected $owner_tree = array();
    protected $main_model = 'Nodes';
    

    public function initialize(){
        parent::initialize();
        $this->loadModel('Nodes');
        $this->loadModel('Users');
       
        $this->loadComponent('Aa');
        $this->loadComponent('GridButtons');
        
        $this->loadComponent('JsonErrors'); 
        $this->loadComponent('TimeCalculations');
             
        $this->loadComponent('Unknowns');
        $this->loadComponent('MeshHelper'); 
    }
    
    public function GetConfigForNode(){
         if(null !== $this->request->getQuery('mac')){
            $mac        = $this->request->getQuery('mac');
            $ent_node   = $this->Nodes->find()->where([$this->main_model.'.mac' => $mac])->first();
            if($ent_node){
                $gw = false;
                if(null !== $this->request->getQuery('gateway')){
                    if($this->request->getQuery('gateway') == 'true'){
                        $gw = true;
                    }
                }
                $json = $this->MeshHelper->JsonForMeshNode($ent_node,$gw);
                $this->set([
                    'config_settings'   => $json['config_settings'],
                    'timestamp'         => $json['timestamp'],
                    'success' => true,
                    '_serialize' => ['config_settings','success','timestamp']
                ]);
                  
            }else{
                $this->Unknowns->RecordUnknownNode();
            }
         }else{
            $this->JsonErrors->errorMessage("MAC Address of node not specified");
         }  
    }

    public function index(){
        //__ Authentication + Authorization __
        $user = $this->_ap_right_check();
        if (!$user) {
            return;
        }
//        $user_id    = $user['id'];
//        $query      = $this->{$this->main_model}->find();
       
        //___ FINAL PART ___
        $this->set([
            'success' => true,
            '_serialize' => ['success']
        ]);
    }

}
