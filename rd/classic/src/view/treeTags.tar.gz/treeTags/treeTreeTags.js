Ext.define('Rd.view.treeTags.treeTreeTags' ,{
    extend      :'Ext.tree.Panel',
    useArrows   : true,
    alias       : 'widget.treeTreeTags',
    store       : 'sTreeTags',
    rootVisible : true,
    rowLines    : true,
    stripeRows  : true,
    border      : false,
    columns: [{
            xtype       : 'treecolumn', //this is so we know which column will show the tree
            text        : i18n('sName'),
            flex        : 1,
            sortable    : true,
            dataIndex   : 'name',
            tdCls       : 'gridTree'
        },
        {
            text        : i18n('sComment'),
            flex        : 2,
            dataIndex   : 'comment',
            sortable    : false,
            tdCls       : 'gridTree'
        }
    ],
    tbar: [      
        { xtype: 'button',  glyph: Rd.config.icnReload, scale: 'large', itemId: 'reload',tooltip: i18n('sReload')},              
        { xtype: 'button',  glyph: Rd.config.icnAdd,    scale: 'large', itemId: 'add',tooltip: i18n('sAdd')},
        { xtype: 'button',  glyph: Rd.config.icnDelete, scale: 'large', itemId: 'delete',tooltip: i18n('sDelete')},
        { xtype: 'button',  glyph: Rd.config.icnEdit,   scale: 'large', itemId: 'edit',tooltip: i18n('sEdit')},
        { xtype: 'button',  glyph: Rd.config.icnExpand, scale: 'large', itemId: 'expand', tooltip: i18n('sExpand')},
        { xtype: 'tbfill'}
    ],
    initComponent: function(){
        var me = this;
        //Create a mask and assign is as a property to the window
        me.mask = new Ext.LoadMask(me, {msg: i18n('sConnecting')+" ...."});
        this.callParent(arguments);
    }
});
